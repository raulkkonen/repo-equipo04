package com.project.docker.ms.producto.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsProductoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsProductoApiApplication.class, args);
	}

}
